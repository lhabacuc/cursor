/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   common.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lhabacuc <lhabacuc@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 21:04:56 by lhabacuc          #+#    #+#             */
/*   Updated: 2024/11/30 12:49:08 by lhabacuc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	cleanup_and_exit(t_philo *philos, t_mutex *lock, char **av)
{
	int	i;


	i = 0;
	while (i < ft_atoi(av[1]))
		pthread_mutex_destroy(&lock[i++]);
	if (philos)
		free(philos);
	if (lock)
		free(lock);
}

int	are_arguments_integers(int ac, char **av)
{
	int		i;
	int		j;
	int		num;
	char	c;

	i = 1;
	num = 1;
	while (i < ac)
	{
		j = 0;
		while (av[i][j] != '\0')
		{
			c = av[i][j];
			if (!(c >= '0' && c <= '9') && av[i][j] != ' ')
			{
				printf(MSG, av[i][j]);
				num = 0;
			}
			j++;
		}
		i++;
	}
	return (num);
}

int	safe_sleep(t_philo *philos, int time)
{
	int	i;

	i = 0;
	if (philos->share->stop)
		return (1);
	while ((time / 10) > i)
	{
		if (current_time(philos->start_time) >= philos->share->time_to_die)
		{
			msg_log(philos, "dead");
			philos->share->stop = 1;
			return (1);
		}
		usleep(1000);
		i++;
	}
	return (0);
}

int	philo_one(t_philo *philos)
{
	msg_log(philos, "has taken a fork");
	usleep(philos->share->time_to_eat * 1000);
	msg_log(philos, "dead");
	return (0);
}
