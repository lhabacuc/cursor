/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   log_utils.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lhabacuc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 21:14:30 by lhabacuc          #+#    #+#             */
/*   Updated: 2024/11/18 21:14:32 by lhabacuc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	ft_atoi(const char *str)
{
	int	sign;
	int	result;

	sign = 1;
	result = 0;
	while (*str == ' ' || *str == '\t' || *str == '\n'
		|| *str == '\v' || *str == '\f' || *str == '\r')
		str++;
	if (*str == '-' || *str == '+')
	{
		if (*str == '-')
			sign = -1;
		str++;
	}
	while (*str >= '0' && *str <= '9')
	{
		if (result > (INT_MAX - (*str - '0')) / 10)
			return (2147483647);
		result = result * 10 + (*str - '0');
		str++;
	}
	return (result * sign);
}

long long	gettime(void)
{
	struct timeval	time;

	gettimeofday(&time, NULL);
	return ((time.tv_sec * 1000) + (time.tv_usec / 1000));
}

long long	current_time(long long start)
{
	return (gettime() - start);
}

void	msg_log(t_philo *philos, char *status)
{
	pthread_mutex_lock(&philos->share->imprim);
	if (philos->share->stop == 0)
		printf("%lld %d %s\n", current_time(philos->start), philos->id, status);
	pthread_mutex_unlock(&philos->share->imprim);
}

void	extra_control(t_philo *ph)
{
	ph->start_time = gettime();
	ph->start = gettime();
	ph->life_time = gettime();
}
