/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lhabacuc <lhabacuc@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 11:17:02 by lhabacuc          #+#    #+#             */
/*   Updated: 2024/11/30 12:57:20 by lhabacuc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"
/*
void	getfork(t_philo *philos)
{
	if (philos->id % 2 == 0)
		{
			pthread_mutex_lock(philos->fork_left);
			msg_log(philos, "has taken a fork");
			pthread_mutex_lock(philos->fork_right);
		}
		else
		{
			pthread_mutex_lock(philos->fork_right);
			msg_log(philos, "has taken a fork");
			pthread_mutex_lock(philos->fork_left);
		}
}


void letfork(t_philo *philos)
{
	if (philos->id % 2 == 0)
		{
			pthread_mutex_unlock(philos->fork_right);
			pthread_mutex_unlock(philos->fork_left);
		}
		else
		{
			pthread_mutex_unlock(philos->fork_left);
			pthread_mutex_unlock(philos->fork_right);
		}
}
*/
void	philo_action_cycle(t_philo *philos)
{
	while (philos->share->food == -1 || philos->food > 0)
	{
		//if (philos->id % 2 == 0)
		//	usleep(1000);
		if (philos->id % 2 != 0)
		{
			pthread_mutex_lock(philos->fork_left);
			msg_log(philos, "has taken a fork");
			pthread_mutex_lock(philos->fork_right);
			msg_log(philos, "has taken a fork");

		}
		else
		{
			pthread_mutex_lock(philos->fork_right);
			msg_log(philos, "has taken a fork");
			pthread_mutex_lock(philos->fork_left);
			msg_log(philos, "has taken a fork");
		}
		msg_log(philos, "is eating");
		safe_sleep(philos, philos->share->time_to_eat);
		pthread_mutex_lock(&philos->share->imprim);
		philos->start_time = gettime();
		philos->food--;
		pthread_mutex_unlock(&philos->share->imprim);
		if (philos->id % 2 != 0)
		{
			pthread_mutex_unlock(philos->fork_right);
			pthread_mutex_unlock(philos->fork_left);
		}
		else
		{
			pthread_mutex_unlock(philos->fork_left);
			pthread_mutex_unlock(philos->fork_right);
		}
		msg_log(philos, "is sleeping");
		safe_sleep(philos, philos->share->time_to_sleep);
		msg_log(philos, "is thinking");
		if (philos->share->stop)
			break ;
	}
}

/*
void	philo_action_cycle(t_philo *philos)
{
	while (philos->share->food == -1 || philos->food > 0)
	{
		if (philos->id % 2 == 0)
			usleep(1000);
		pthread_mutex_lock(philos->fork_left);
		msg_log(philos, "has taken a fork");
		pthread_mutex_lock(philos->fork_right);
		msg_log(philos, "has taken a fork");
		msg_log(philos, "is eating");
		safe_sleep(philos, philos->share->time_to_eat);
		philos->start_time = gettime();
		philos->food--;
		pthread_mutex_unlock(philos->fork_right);
		pthread_mutex_unlock(philos->fork_left);
		msg_log(philos, "is sleeping");
		safe_sleep(philos, philos->share->time_to_sleep);
		msg_log(philos, "is thinking");
		if (philos->share->stop)
			break ;
	}
}
*/
void	*philo_life_cycle(void *arg)
{
	t_philo	*philos;

	philos = (t_philo *)arg;
	extra_control(philos);
	if (num_philo(-1) == 1)
		philo_one(philos);
	else
		philo_action_cycle(philos);
	return (NULL);
}

void	init_share(char **av, t_share *share, t_philo **philos, t_mutex **lock)
{
	if (count_agrs(av) == 5 || count_agrs(av) == 6)
	{
		share->time_to_die = atoi(av[2]);
		share->time_to_eat = atoi(av[3]);
		share->time_to_sleep = atoi(av[4]);
		share->food = -1;
		share->stop = 0;
		pthread_mutex_init(&share->imprim, NULL);
		if (count_agrs(av) == 6)
			share->food = atoi(av[5]);
		*philos = malloc(sizeof(t_philo) * atoi(av[1]));
		if (!*philos)
			return ;
		*lock = malloc(sizeof(t_mutex) * atoi(av[1]));
		if (!*lock)
			return ;
	}
}

void	init_philo_data(t_philo *philos, int i, t_mutex *lock, t_share *share)
{
	philos->id = i + 1;
	philos->fork_left = &lock[i];
	philos->fork_right = &lock[(i + 1) % num_philo(-1)];
	philos->food = share->food;
	philos->life_time = 0;
	philos->start_time = 0;
	philos->start = 0;
	philos->share = share;
}

void	init_forks(char **av, t_philo *philos, t_mutex *lock, t_share *share)
{
	int	i;

	i = 0;
	while (i < atoi(av[1]))
	{
		pthread_mutex_init(&lock[i], NULL);
		i++;
	}
	i = 0;
	while (i < atoi(av[1]))
	{
		init_philo_data(&philos[i], i, lock, share);
		pthread_create(&philos[i].philos, NULL, philo_life_cycle, &philos[i]);
		i++;
	}
	i = 0;
	while (i < ft_atoi(av[1]))
		pthread_join(philos[i++].philos, NULL);
}

int	main(int ac, char **av)
{
	t_philo		*philos;
	t_mutex		*lock;
	t_share		share;
	int			i;

	i = 0;
	if (ac == 5 || ac == 6)
	{
		if (!are_arguments_integers(ac, av))
			return (1);
		num_philo(atoi(av[1]));
		init_share(av, &share, &philos, &lock);
		if (philos == NULL || lock == NULL)
			return (0);
		init_forks(av, philos, lock, &share);
		cleanup_and_exit(philos, lock, av);
	}
	else
		i = show_warning();
	return (i);
}
