/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lhabacuc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 11:31:14 by lhabacuc          #+#    #+#             */
/*   Updated: 2024/11/18 11:31:22 by lhabacuc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

# include <unistd.h>
# include <stdio.h>
# include <limits.h>
# include <stdlib.h>
# include <sys/time.h>
# include <pthread.h>
# define MSG "\033[1;33mAVISO:\033[0m apenas números inteiros positivos `%c'\n"

typedef pthread_mutex_t	t_mutex;
typedef pthread_t		t_thead;

typedef struct s_share
{
	int				time_to_die;
	int				time_to_eat;
	int				time_to_sleep;
	int				food;
	_Atomic int		stop;
	t_mutex			imprim;
}	t_share;

typedef struct s_philo
{
	t_thead		philos;
	t_mutex		*fork_left;
	t_mutex		*fork_right;
	int			food;
	int			id;
	long long	life_time;
	long long	start_time;
	long long	start;
	t_share		*share;
}	t_philo;

long long	current_time(long long start);
long long	gettime(void);
int			num_philo(int s);
int			isnum(char c);
int			show_warning(void);
int			count_agrs(char **av);
int			ft_atoi(const char *str);
void		extra_control(t_philo *ph);
void		philo_eat(t_philo *philos);
void		philo_rest_and_think(t_philo *philos);
void		msg_log(t_philo *philos, char *status);
void		cleanup_and_exit(t_philo *philos, t_mutex *lock, char **av);
int			philo_one(t_philo *philos);
int			are_arguments_integers(int ac, char **av);
int			safe_sleep(t_philo *philos, int time);

#endif
