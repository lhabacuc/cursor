/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   log2.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lhabacuc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 21:32:03 by lhabacuc          #+#    #+#             */
/*   Updated: 2024/11/18 21:32:11 by lhabacuc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	philo_eat(t_philo *philos)
{
	t_mutex	*fork_left;
	t_mutex	*fork_right;

	if (philos->id % 2 == 0)
	{
		fork_left = philos->fork_left;
		fork_right = philos->fork_right;
	}
	else
	{
		fork_left = philos->fork_right;
		fork_right = philos->fork_left;
	}
	pthread_mutex_lock(fork_left);
	msg_log(philos, "has taken a fork");
	pthread_mutex_lock(fork_right);
	msg_log(philos, "has taken a fork");
	msg_log(philos, "is eating");
	safe_sleep(philos, philos->share->time_to_eat);
	philos->start_time = gettime();
	philos->food--;
	pthread_mutex_unlock(fork_right);
	pthread_mutex_unlock(fork_left);
}

void	philo_rest_and_think(t_philo *philos)
{
	msg_log(philos, "is sleeping");
	safe_sleep(philos, philos->share->time_to_sleep);
	msg_log(philos, "is thinking");
	if (philos->share->stop)
		return;
}

int	num_philo(int s)
{
	static int	var = 0;

	if (s == -1)
		return (var);
	var = s;
	return (var);
}

int	show_warning(void)
{
	printf(" \033[1;33mAVISO:\033[0m Parâmetros esperados:\n");
	printf("--------------------------------------------------------\n");
	printf("   1▪️ Número de filósofos: \n");
	printf("   2▪️ Tempo para morrer (time_to_die) em milissegundos: \n");
	printf("   3▪️ Tempo para comer (time_to_eat) em milissegundos: \n");
	printf("   4▪️ Tempo para dormir (time_to_sleep) em milissegundos: \n");
	printf("   5▪️ Número de vezes que cada filósofo deve comer: \n");
	printf("--------------------------------------------------------\n");
	printf(" ./philo <1> <2> <3> <4> <5> \n");
	return (1);
}

int	count_agrs(char **av)
{
	int	i;

	i = 0;
	while (av[i])
		i++;
	return (i);
}
