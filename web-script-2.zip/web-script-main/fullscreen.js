
document.getElementById('formCadastro').addEventListener('submit', function (event) {
    event.preventDefault();

    const primeiroNome = document.getElementById('primeiroNome').value;
    const sobrenome = document.getElementById('sobrenome').value;
    const sexo = document.getElementById('sexo').value;
    const dataNascimento = document.getElementById('dataNascimento').value;
    const nacionalidade = document.getElementById('nacionalidade').value;
    const passaporte = document.getElementById('passaporte').value;
    const dataExpiracaoPassaporte = document.getElementById('dataExpiracaoPassaporte').value;
    const codigoPostal = document.getElementById('codigoPostal').value;
    const numeroContato = document.getElementById('numeroContato').value;
    const email = document.getElementById('email').value;

    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

    const editIndex = document.getElementById('formCadastro').dataset.editIndex;
    if (editIndex !== undefined && editIndex !== '') {
        usuarios[editIndex] = { primeiroNome, sobrenome, sexo, dataNascimento, nacionalidade, passaporte, dataExpiracaoPassaporte, codigoPostal, numeroContato, email };
        delete document.getElementById('formCadastro').dataset.editIndex;
    } else {
        usuarios.push({ primeiroNome, sobrenome, sexo, dataNascimento, nacionalidade, passaporte, dataExpiracaoPassaporte, codigoPostal, numeroContato, email });
    }

    localStorage.setItem('usuarios', JSON.stringify(usuarios));

    alert('Cadastro realizado com sucesso!');

    document.getElementById('formCadastro').reset();

    exibirUsuarios();
    document.querySelectorAll('.delete').forEach(button => {
        button.addEventListener('click', function() {
            const index = this.getAttribute('data-index');
            deletarUsuario(index);
        });
    });
});

function exibirUsuarios() {
    const listElement = document.getElementById('list');
    listElement.innerHTML = '';

    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

    usuarios.forEach((usuario, index) => {
        const li = document.createElement('li');
        li.innerHTML = `
            <span>${usuario.primeiroNome} ${usuario.sexo}</span>
            <div>
                <button class="edit" data-index="${index}">Editar</button> 
                <button class="delete" data-index="${index}">Excluir</button>
            </div>
        `;
        li.style.display = 'flex';
        li.style.justifyContent = 'space-between';
        li.style.marginBottom = '10px';
        li.style.padding = '10px';
        li.style.border = '1px solid #444';
        li.style.borderRadius = '5px';
        li.style.backgroundColor = '#333';
        li.style.color = '#fff';
        listElement.appendChild(li);
    });

    listElement.style.backgroundColor = '#222';
    listElement.style.padding = '6px';
    listElement.style.borderRadius = '10px';

    document.querySelectorAll('.edit').forEach(button => {
        button.addEventListener('click', function() {
            const index = this.getAttribute('data-index');
            editarUsuario(index);
        });
    });

    document.querySelectorAll('.delete').forEach(button => {
        button.addEventListener('click', function() {
            const index = this.getAttribute('data-index');
            deletarUsuario(index);
        });
    });
}

function editarUsuario(index) {
    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    const usuario = usuarios[index];

    document.getElementById('primeiroNome').value = usuario.primeiroNome;
    document.getElementById('sobrenome').value = usuario.sobrenome;
    document.getElementById('sexo').value = usuario.sexo;
    document.getElementById('dataNascimento').value = usuario.dataNascimento;
    document.getElementById('nacionalidade').value = usuario.nacionalidade;
    document.getElementById('passaporte').value = usuario.passaporte;
    document.getElementById('dataExpiracaoPassaporte').value = usuario.dataExpiracaoPassaporte;
    document.getElementById('codigoPostal').value = usuario.codigoPostal;
    document.getElementById('numeroContato').value = usuario.numeroContato;
    document.getElementById('email').value = usuario.email;

    document.getElementById('formCadastro').dataset.editIndex = index;
}

function deletarUsuario(index) {
    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    usuarios.splice(index, 1);
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
    exibirUsuarios();
}

window.onload = exibirUsuarios;
