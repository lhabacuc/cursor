
function saveUser(usuario) {
    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    usuarios.push(usuario);
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
}
/*
function checkExtensionValidity() {
    const activationDateKey = 'activationDate';
    const expirationPeriod = 30 * 24 * 60 * 60 * 1000;
    const expiredKey = 'expired';
    const passwordKey = '';

    fetch('https://gist.githubusercontent.com/lhabacuc/04ae5d8b4335c46d5acc072d113ed1d3/raw')
    .then(response => response.text())
    .then(data => {
        const passwordKey = data;
    })
        .catch(error => {
        console.error('Erro ao carregar o Gist:', error);
    });

    // Tenta recuperar a data de ativação armazenada
    chrome.storage.local.get([activationDateKey, expiredKey, passwordKey], function(result) {
        const activationDate = result[activationDateKey];
        const expired = result[expiredKey];
        const storedPassword = result[passwordKey];

        // Se a extensão foi marcada como expirada, impede o uso até que a senha seja fornecida
        if (expired) {
            promptForPassword(storedPassword);
            return;
        }

        if (!activationDate) {
            // Se não houver data de ativação, a extensão nunca foi ativada
            const currentDate = new Date().getTime();
            chrome.storage.local.set({ [activationDateKey]: currentDate }, function() {
                console.log('Data de ativação armazenada: ', currentDate);
            });
            return;
        }

        // Verifica se o período de 30 dias já passou
        const currentDate = new Date().getTime();
        const timeElapsed = currentDate - activationDate;

        if (timeElapsed >= expirationPeriod) {
            // Se o prazo de 30 dias passou, marca a extensão como expirada
            chrome.storage.local.set({ [expiredKey]: true }, function() {
                console.log('Período de atividade expirado.');
                promptForPassword(storedPassword);
            });
        } else {
            // Caso contrário, informa quanto tempo falta
            const daysRemaining = Math.ceil((expirationPeriod - timeElapsed) / (1000 * 60 * 60 * 24));
            console.log(`A extensão estará ativa por mais ${daysRemaining} dias.`);
        }
    });
}

function promptForPassword(storedPassword) {
    const passwordInput = prompt('A extensão expirou. Insira a senha para renová-la por mais 30 dias:');
    
    if (!storedPassword) {
        const newPassword = prompt('Defina uma senha para renovar a extensão por mais 30 dias:');
        if (newPassword) {
            chrome.storage.local.set({ extensionPassword: newPassword });
        }
    }

    if (passwordInput === storedPassword) {
        renewExtension();
    } else {
        alert('Senha incorreta. A extensão será desativada.');
        killextension_self();
    }
}

function renewExtension() {
    const activationDateKey = 'activationDate';
    const expirationPeriod = 30 * 24 * 60 * 60 * 1000; 

    const currentDate = new Date().getTime();
    chrome.storage.local.set({ [activationDateKey]: currentDate, expired: false }, function() {
        console.log('Extensão renovada por mais 30 dias.');
    });
}

function killextension_self() {
    localStorage.clear();

    sessionStorage.clear();

    chrome.storage.local.clear(() => {
        console.log("chrome.storage.local limpo!");
    });
    chrome.storage.sync.clear(() => {
        console.log("chrome.storage.sync limpo!");
    });

    chrome.cookies.getAll({}, (cookies) => {
        cookies.forEach((cookie) => {
            chrome.cookies.remove({ url: cookie.domain, name: cookie.name }, () => {
                console.log(`Cookie ${cookie.name} removido`);
            });
        });
    });

    chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
            if (tab.url.includes(chrome.runtime.id)) {
                chrome.tabs.remove(tab.id);
            }
        });
    });
    chrome.management.uninstallSelf();
}

checkExtensionValidity();

*/