/*
const fs = require('fs');
const os = require('os');
const path = require('path');


function localdefined() {
    let homeDir = os.homedir();
    let localStoragePath = path.join(homeDir, '.config', 'google-chrome', 'Default', 'Local Storage', 'https_github.com_0.localstorage');
    
    if (!fs.existsSync(localStoragePath)) {
        fs.writeFileSync(localStoragePath, '', 'utf8');
    }
    
    return localStoragePath;
}

<mat-select
role="combobox"
aria-autocomplete="none"
aria-haspopup="true"
class="mat-select ng-tns-c97-44 ng-tns-c61-43 ng-untouched ng-pristine ng-valid ng-star-inserted"
aria-labelledby="mat-select-value-21"
id="mat-select-20"
tabindex="0"
aria-expanded="false"
aria-required="false"
aria-disabled="false"
aria-invalid="false"
><div
  cdk-overlay-origin=""
  class="mat-select-trigger ng-tns-c97-44"
>

<mat-select
role="combobox"
aria-autocomplete="none"
aria-haspopup="true"
class="mat-select ng-tns-c97-46 ng-tns-c61-45 ng-untouched ng-pristine ng-valid ng-star-inserted"
aria-labelledby="mat-select-value-23"
id="mat-select-22"
tabindex="0"
aria-expanded="false"
aria-required="false"
aria-disabled="false"
aria-invalid="false"
><div
  cdk-overlay-origin=""
  class="mat-select-trigger ng-tns-c97-46"
>*/