// Função para exibir os usuários armazenados
function exibirUsuarios() {
    const listElement = document.getElementById('list');
    listElement.innerHTML = '';

    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

    function retaisletras(sobrenome, n = 1) {
        return sobrenome.substring(0, n) + "...";
    }
    usuarios.forEach(usuario => {
        let li = document.createElement("div");
        li.style.maxWidth = "300px"; 
        li.style.wordWrap = "break-word";
        li.innerHTML = `
            <div class="btn">
                ${usuario.primeiroNome} ${retaisletras(usuario.sobrenome, 3)}
            </div>
        `;

        li.addEventListener("click", () => {
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: getTextFromElement,
                    args: [usuario]
                }, (results) => {
                    const resultText = results[0]?.result || "Elemento não encontrado!";
                    console.log(resultText);
                });
            });
        });

        listElement.appendChild(li);
    });
}

function alerta_id_encontrado( id) {
alert("ID encontrado: " + id);
}

function getTextFromElement(usuario) {
    function encontrarIdComPrefixo(prefix, posicao, tipoElemento) {
        const todosIds = Array.from(document.querySelectorAll('[id]'));
        
        const idsFiltrados = todosIds.filter(elemento => 
          elemento.id.startsWith(prefix) && 
          (!tipoElemento || elemento.tagName.toLowerCase() === tipoElemento.toLowerCase())
        );
        if (posicao <= 0 || posicao > idsFiltrados.length) {
          return "elemento não encontrado";
        }
        
        return idsFiltrados[posicao - 1].id;
    }

    function encontrarIdSelectComPrefixo(prefix, posicao) {
        const todosIds = Array.from(document.querySelectorAll('[id]'));
        
        const idsFiltrados = todosIds.filter(elemento => 
          elemento.id.startsWith(prefix) && 
          elemento.tagName.toLowerCase() === "mat-select"
        );
        if (posicao <= 0 || posicao > idsFiltrados.length) {
          return "elemento não encontrado";
        }
        return idsFiltrados[posicao - 1].id;
    }
   // console.log("Entrou na função getTextFromElement " + encontrarIdComPrefixo("mat-input-", 1, "input")); 
    const username = document.querySelector("#" + encontrarIdComPrefixo("mat-input-", 1, "input"));
    const sobrenome = document.querySelector("#" + encontrarIdComPrefixo("mat-input-", 2, "input"));
    const data = document.querySelector("#dateOfBirth");
    const n_pass = document.querySelector("#" + encontrarIdComPrefixo("mat-input-", 3, "input"));
    const dataExpiracaoPassaporte = document.querySelector("#passportExpirtyDate");
    const codigoPostal = document.querySelector("#" + encontrarIdComPrefixo("mat-input-", 4, "input"));
    const numeroContato = document.querySelector("#" + encontrarIdComPrefixo("mat-input-", 5, "input"));
    const email = document.querySelector("#" + encontrarIdComPrefixo("mat-input-", 6, "input"));
    const nacionalidade = document.querySelector("#" + encontrarIdSelectComPrefixo("mat-select-", 1));
    const sexo = document.querySelector("#" + encontrarIdSelectComPrefixo("mat-select-", 2));
    console.log("Entrou na função getTextFromElement " + username.value ? "Campo preenchido com sucesso!" : "Campo não encontrado!");
    console.log("Entrou na função getTextFromElement " +  encontrarIdSelectComPrefixo("mat-select-", 1) + " " +  encontrarIdSelectComPrefixo("mat-select-", 2));
    if (username) {
        username.value = usuario.primeiroNome ; 
        sobrenome.value = usuario.sobrenome ;
        data.value = usuario.dataNascimento ;
        nacionalidade.value = usuario.nacionalidade ;
        sexo.value = usuario.sexo ;
        n_pass.value = usuario.passaporte ;
        dataExpiracaoPassaporte.value = usuario.dataExpiracaoPassaporte ;
        codigoPostal.value = usuario.codigoPostal ;
        numeroContato.value = usuario.numeroContato ;
        email.value = usuario.email ;
        return "Campo preenchido com sucesso!";
    } else {
        return "Campo não encontrado!";
    }
}

document.getElementById("openFullscreen").addEventListener("click", function () {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentTab = tabs[0];
        const currentUrl = currentTab.url;

        chrome.tabs.create({
            url: `fullscreen.html?sourceUrl=${encodeURIComponent(currentUrl)}`
        });
    });
});

window.onload = exibirUsuarios;

/*
document.getElementById("openFullscreen").addEventListener("click", function () {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentTab = tabs[0];
        const currentUrl = currentTab.url;

        chrome.windows.create({
            url: `fullscreen.html?sourceUrl=${encodeURIComponent(currentUrl)}`,
            type: "popup",
            width: screen.availWidth,
            height: screen.availHeight
        });
    });
});

document.getElementById("openFullscreen3").addEventListener("click", function () {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentTab = tabs[0];
        const currentUrl = currentTab.url;

        chrome.tabs.create({
            url: `fullscreen.html?sourceUrl=${encodeURIComponent(currentUrl)}`
        });
    });
}); */